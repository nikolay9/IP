package introduction;

public class Main {

	public static int add_integers(int x, int y){
		int b = x + y;
		return b;
	}
	
	public static String concatenate_strings(String s, String c){
		String sc = s.concat(c);
		return sc;
	}
	
	public static int compare_integers(int x, int y){
		if (x == y) {
			return 0;
		} else {
			return 1;
		}
	}
	
	public static int compare_strings(String s, String c){
		if (s.equals(c)){
			return 0;
		}
		else {
			return 1;
		}
	}
	
	public static void main(String[] args) {
		int x = 6;
		int y = 12;
	    
		String xs = "this is a string";
		String ys = "another string";
		
		int b = add_integers(x, y);
		int c = compare_integers(x, y);
		
		String cs = concatenate_strings(xs, ys);
		int ms = compare_strings(xs, ys);
		
		System.out.println(b);
		if (c != 1){
			System.out.println(c);
		}
		System.out.println(cs);
		if (ms != 1){
			System.out.println(ms);
		}
	}

}
