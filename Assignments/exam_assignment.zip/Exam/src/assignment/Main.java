package assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Main {

	private static ArrayList<String> list1 = new ArrayList<String>();
	private static ArrayList<String> list2 = new ArrayList<String>();
	private static ArrayList<String> result = new ArrayList<String>();
	
	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, IOException, TransformerException {
		final Document input_1 = openDocument("src/xml/input_1.xml");
		final Document input_2 = openDocument("src/xml/input_2.xml");
		final Document output_document = openDocument("src/xml/output.xml");
		process(output_document);
		result = compareLists(list1, list2);
		// v momenta list1 i list2 sa prazni, ne pravish nishto
		// napravih metod koito da ti vzima imenata decata na root elementa
		
		saveDocument(result, "src/output4.xml");
	}

	private static void saveDocument(ArrayList<String> result_list, String filename)
			throws FileNotFoundException, TransformerException {
		final TransformerFactory factory = TransformerFactory.newInstance();
		factory.setAttribute("indent-number", 2);
		final Transformer transformer = factory.newTransformer();
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		
		// tuk trqbva da napravish taka che rezultatite ot lista da se zapazvat kym root elementa
		// purvo trqbva da go suzdadesh
		// posle da obhodish celiq list i da dobavqsh elementite kum nego
		// tova tuk dolu, nqma da raboti zashtoto kopira edin dokument kum drug.
		// kakvo e void?
		// kak se izpolzvat metodi?
		// razuchi "method scope java", "function scope java", "local scope java", "class scope java", "global scope java"
		
		/*final StreamResult out = new StreamResult(new FileOutputStream(
				new File(filename)));
		transformer.transform(new DOMSource(document), out);*/
	}


	private static void process(Document document) {
		final Node root = document.getFirstChild();
		Element element = document.createElement("append");
		element.appendChild(document.createTextNode("I append."));
		root.appendChild(element);
	}

	public static ArrayList<String> compareLists(ArrayList<String> argumenten_list_1, ArrayList<String> argumenten_list_2) {
		ArrayList<String> compared = new ArrayList<String>();
		for (String a : argumenten_list_1) {
			for (String b : argumenten_list_2) {
				if (a.equals(b)) {
					compared.add(a);
				}
			}
		}
		return compared;
	}
	
	public void getMovieNames(Document document, ArrayList<String> to_append){
		   Node root = document.getFirstChild();
	       NodeList child_nodes = root.getChildNodes();

			for (int a = 0; a < child_nodes.getLength(); a++) {
			    Node child = child_nodes.item(a);
			    System.out.println(child.getNodeName());
			    to_append.add(child.getNodeName());
			}
	}


	private static Document openDocument(String filename)
			throws ParserConfigurationException, SAXException, IOException {
		final DocumentBuilderFactory factory = DocumentBuilderFactory
				.newInstance();
		final DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new File(filename));
	}

}
