package fileIO;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class ioexamples {
	public static char[] BUFFER = new char[50];
	
	
	public static void main(String[] args) throws IOException {
		read_input();
		read_document();
		copy_document();
		write_to_document();
	}


	private static void write_to_document() throws IOException {
		File output = new File("file_output.txt");
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter writer = new BufferedWriter(new FileWriter(output));

		while(true){
			int x = reader.read();
			writer.write(x);
			if (x == 9){
				reader.close();
				writer.close();
				break;
			}
		}
	}


	private static void copy_document() throws NumberFormatException, IOException {
		File input = new File("file_input.txt");
		File output = new File("file_output.txt");
		
		BufferedReader reader = new BufferedReader(new FileReader(input));
		BufferedWriter writer = new BufferedWriter(new FileWriter(output));
		
		String text = "";
		while ((text = reader.readLine()) != null) {
	        writer.write(text);
	    }
		reader.close();
		writer.close();
	}


	private static void read_document() throws NumberFormatException, IOException {
		File file = new File("input.txt");
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String text = "";
		while ((text = reader.readLine()) != null) {
	        System.out.println(Integer.parseInt(text));
	    }
		reader.close();
	}


	private static void read_input() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		reader.read(BUFFER);
		System.out.println(BUFFER);
		reader.close();
	}

}
