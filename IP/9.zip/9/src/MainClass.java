import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MainClass {

   

    public static void main(String[] args) throws TransformerException,
            ParserConfigurationException, SAXException, IOException {
        final Document document = openDocument("src/9.xml");
        process(document);
       
    }

   

    private static void process(Document document) {
        Node root = document.getFirstChild();
        NamedNodeMap atributes = root.getAttributes();

        if (root.hasAttributes()) {
            for (int a = 0; a < atributes.getLength(); a++) {
                Node atribut = atributes.item(a);
                System.out.println(atribut.getNodeName() + "-"
                        + atribut.getNodeValue());
            }
        }
    }

    private static Document openDocument(String filename)
            throws ParserConfigurationException, SAXException, IOException {
        final DocumentBuilderFactory factory = DocumentBuilderFactory
                .newInstance();
        final DocumentBuilder builder = factory.newDocumentBuilder();
        return builder.parse(new File(filename));
    }
}