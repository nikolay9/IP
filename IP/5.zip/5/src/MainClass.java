
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MainClass {

    private static final short GET_NODE_TYPE = 1;

    public static void main(String[] args) throws TransformerException,
            ParserConfigurationException, SAXException, IOException {
        final Document document = openDocument("src/input.xml");
        process(document);
       
    }

    private static void saveDocument(Document document, String filename)
            throws FileNotFoundException, TransformerException {
        final TransformerFactory factory = TransformerFactory.newInstance();
        factory.setAttribute("indent-number", 2);
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

        final StreamResult out = new StreamResult(new FileOutputStream(
                new File(filename)));
        transformer.transform(new DOMSource(document), out);
    }

    private static void process(Document document) {
        Node root = document.getFirstChild();
        NodeList children = root.getChildNodes();
        for (int a = 0; a < children.getLength(); a++) {
            Node element = children.item(1);

            if (element.getNodeType() == GET_NODE_TYPE) {

                System.out.println(element.getNodeName());
                return;
            }
        }
    }

    private static Document openDocument(String filename)
            throws ParserConfigurationException, SAXException, IOException {
        final DocumentBuilderFactory factory = DocumentBuilderFactory
                .newInstance();
        final DocumentBuilder builder = factory.newDocumentBuilder();
        return builder.parse(new File(filename));
    }
}