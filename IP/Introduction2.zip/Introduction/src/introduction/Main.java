package introduction;

public class Main {

	public static int add_integers(int x, int y){
		int b = x + y;
		return b;
	}//vru6ta tip ineger 
	
	public static String concatenate_strings(String s, String c){
		String sc = s.concat(c);//concat dobavq string c kum kraq na string s
		return sc;
	}//metoda concatenate subira 2 stringa s i c
	/* tiput na vru6tanata stoinost e string*/
	public static int compare_integers(int x, int y){
		if (x == y) {
			return 0;
		} else {
			return 1;
		}
	}//tiput koqto vru6ta compare_integers e integer
	
	public static int compare_strings(String s, String c){
		if (s.equals(c)){
			return 0;
		}
		else {
			return 1;
		}
	}//tiput koqto vru6ta compare_strings e integer
	public static int newfunction (int e ,int z){
		int d=e+z;
		d=d*2;
		return d;
	}
	
	public static void main(String[] args) {
		int x = 6;
		int y = 12;
		
	   //
		int e=2;
	    int z=3;
	   int k=newfunction(e,z);
	   System.out.println(k);
	   //
	   
		String xs = "this is a string";
		String ys = "another string";
		
		int b = add_integers(x, y);
		int c = compare_integers(x, y);
		
		String cs = concatenate_strings(xs, ys);
		int ms = compare_strings(xs, ys);
		
		System.out.println(b);
		if (c != 0){
			System.out.println(c);
		}
		System.out.println(cs);
		if (ms != 0){
			System.out.println(ms);
		}
	}

}
