import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class MainClass {

    public static void main(String[] args) throws TransformerException,
            ParserConfigurationException, SAXException, IOException {
        final Document document = openDocument("src/NewFile.xml");
        process(document);
        saveDocument(document, "src/NewFile1.xml");
    }

    private static void saveDocument(Document document, String filename)
            throws FileNotFoundException, TransformerException {
        final TransformerFactory factory = TransformerFactory.newInstance();
        factory.setAttribute("indent-number", 2);
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

        final StreamResult out = new StreamResult(new FileOutputStream(
                new File(filename)));
        transformer.transform(new DOMSource(document), out);
    }

    private static void process(Document document) {
        Node root = document.getFirstChild();
        Element child = document.createElement("aaa");
        root.appendChild(child);

    }

    private static Document openDocument(String filename)
            throws ParserConfigurationException, SAXException, IOException {
        final DocumentBuilderFactory factory = DocumentBuilderFactory
                .newInstance();
        final DocumentBuilder builder = factory.newDocumentBuilder();
        return builder.parse(new File(filename));
    }
}