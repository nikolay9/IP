import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MainClass {

	private static final short GET_NODE_TYPE = 1;

	static ArrayList<String> first = new ArrayList<String>();
	static ArrayList<String> second = new ArrayList<String>();
	static ArrayList<String> list3 = new ArrayList<String>();

	public static void main(String[] args) throws TransformerException,
			ParserConfigurationException, SAXException, IOException {
		final Document document = openDocument("src/20.xml");
		final Document document2 = openDocument("src/21.xml");

		first = getMovieName(document, first);
		second = getMovieName(document2, second);
		list3 = compareLists(first, second);

	}

	public static ArrayList<String> getMovieName(Document document,
			ArrayList<String> list) {
		Node root = document.getFirstChild();

		NodeList child = root.getChildNodes();
		for (int i = 0; i < child.getLength(); i++) {
			Node element = child.item(i);
			if (element.getNodeType() == GET_NODE_TYPE) {
				if (element.getNodeName().equals("movie")) {
					if (element.hasAttributes()) {
						NamedNodeMap attributes1 = element.getAttributes();
						for (int k = 0; k < attributes1.getLength(); k++) {
							Node attribut1 = attributes1.item(k);

							if (attribut1.getNodeName().equals("name")) {
								list.add(attribut1.getNodeName());

							}
						}
					}
				}
			}
		}

		return list;

	}

	private static ArrayList<String> compareLists(ArrayList<String> first,
			ArrayList<String> second) {
		ArrayList<String> list3 = new ArrayList<String>();

		for (String a : first) {
			for (String b : second) {

				if (a.equals(b)) {
					list3.add(a);
				}
			}
		}
		return list3;

	}

	private static void process(Document document) {
		Node root = document.getDocumentElement();
		NodeList children = root.getChildNodes();

		for (int a = 0; a < children.getLength(); a++) {
			Node element = children.item(a);
			if (matches(element)) {
				System.out.println(element.getNodeName());

			}

		}

	}

	private static boolean matches(Node element) {
		if (element.getNodeType() == GET_NODE_TYPE) {

			if (element.hasAttributes()) {

				NamedNodeMap attributes = element.getAttributes();

				for (int l = 0; l < attributes.getLength(); l++) {

					Node attribute = attributes.item(l);
					if (attribute.getNodeName().equals("a")) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private static Document openDocument(String filename)
			throws ParserConfigurationException, SAXException, IOException {
		final DocumentBuilderFactory factory = DocumentBuilderFactory
				.newInstance();
		final DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new File(filename));
	}
}