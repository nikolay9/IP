import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MainClass {

	private static final short GET_NODE_TYPE = 1;

	static ArrayList<String> first = new ArrayList<String>();
	static ArrayList<String> second = new ArrayList<String>();
	static ArrayList<String> list3 = new ArrayList<String>();

	public static void main(String[] args) throws TransformerException,
			ParserConfigurationException, SAXException, IOException {
		final Document document = openDocument("src/20.xml");
		final Document document2 = openDocument("src/21.xml");
		final Document document3 = openDocument("src/23.xml");
		first = getMovieName(document, first);
		second = getMovieName(document2, second);
		list3 = compareLists(first, second);
		addResult(list3, document3);
		saveDocument(document3, "src/23.xml");
	}

	public static ArrayList<String> getMovieName(Document document,
			ArrayList<String> list) {
		Node root = document.getFirstChild();

		NodeList child = root.getChildNodes();
		for (int i = 0; i < child.getLength(); i++) {
			Node element = child.item(i);
			if (element.getNodeType() == GET_NODE_TYPE) {
				if (element.getNodeName().equals("movie")) {
					if (element.hasAttributes()) {
						NamedNodeMap attributes1 = element.getAttributes();
						for (int k = 0; k < attributes1.getLength(); k++) {
							Node attribut1 = attributes1.item(k);

							if (attribut1.getNodeName().equals("name")) {
								list.add(attribut1.getNodeValue());

							}
						}
					}
				}
			}
		}

		return list;

	}

	private static ArrayList<String> compareLists(ArrayList<String> first,
			ArrayList<String> second) {
		ArrayList<String> list3 = new ArrayList<String>();

		for (String a : first) {
			for (String b : second) {

				if (a.equals(b)) {
					list3.add(a);
				}
			}
		}
		return list3;

	}

	private static void addResult(ArrayList<String> list3, Document document3) {
		Node root = document3.getFirstChild();

		for (String c : list3) {

			Element element = document3.createElement("movie");
			element.setAttribute("name", c);
			root.appendChild(element);
		}
	}

	private static void saveDocument(Document document, String filename)
			throws FileNotFoundException, TransformerException {
		final TransformerFactory factory = TransformerFactory.newInstance();
		factory.setAttribute("indent-number", 2);
		Transformer transformer = factory.newTransformer();
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

		final StreamResult out = new StreamResult(new FileOutputStream(
				new File(filename)));
		transformer.transform(new DOMSource(document), out);
	}

	private static Document openDocument(String filename)
			throws ParserConfigurationException, SAXException, IOException {
		final DocumentBuilderFactory factory = DocumentBuilderFactory
				.newInstance();
		final DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new File(filename));
	}
}